#!/usr/bin/env python3

import influxdb
from statistics import stdev, mean, median
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import lmfit

HOST = 'influx.linklab.virginia.edu'
PORT = 443
USERNAME = 'ryan'
PASSWORD = 'gae7shaerai9Xiem9eilae5shiGhuich4Gu'
DATABASE = 'gateway-generic'

client = influxdb.InfluxDBClient(HOST, PORT, USERNAME, PASSWORD, DATABASE, ssl=True, verify_ssl=True)

device_locations = ['Sensor A', 'Sensor B', 'Sensor Wall', 'Sensor Vertical']
device_ids = ['70886b123059', '70886b1235d4', '70886b1277ca', '70886b1230f2']

#--------------------------------------------
# Functions
#--------------------------------------------

def exponential_function(x, a, b, c):
    return a * np.exp(-b * x) + c

def f1(x, a0, a1, a2, a3):
    #https://stackoverflow.com/questions/34471006/how-to-determine-function-or-curve-fit-unknown-function-with-python
    return a0 + a1/x + a2/x**2 + a3/x**3

def f2(x, a0, a1, a2, a3):
    #https://stackoverflow.com/questions/34471006/how-to-determine-function-or-curve-fit-unknown-function-with-python
    return a0 + a1*x + a2*x**2 + a3*x**3

def logistic_function(x, x_0, L, k):
    #https://www.architecture-performance.fr/ap_blog/fitting-a-logistic-curve-to-time-series-in-python/
    return L/(1+np.exp(-k*(x-x_0)))    

def pull_awair_voc_data(start_time, end_time, device_id):
    '''
    This program checks to see if there are any VOC spikes by an inputted sensor

    TODO
    '''
    #Gets the value for the sensor that works\
    result = client.query("SELECT MEAN(value) FROM voc_ppb WHERE (device_id = \'" + device_id + "\') and time > " + start_time + " and time < " + end_time + " GROUP BY location_specific, time(10s) fill(null)")
    score_list = []
    #For each element in the VOC data, grab the score and time. Within the score and time, grab just the score (aka the mean)
    for element in result.items():
                score_and_time = list(element[1])
                for item in score_and_time:
                    score_list.append(item['mean'])
    return score_list

def pull_new_voc_data(start_time, end_time):
    '''
    TODO
    '''
    #Pull all data for each individual sensor for a selected timeframe
    sensirion_result = client.query("SELECT mean(value) FROM voc_index WHERE (sensors = \'Sensirion_SEN54\') AND time > " + start_time + " and time < " + end_time + " GROUP BY time(10s) fill(null)")
    ec_result = client.query("SELECT mean(value) FROM voc_ppb WHERE (sensor = \'EC_Sense_PS1_VOC\') AND time > " + start_time + " and time < " + end_time + " GROUP BY time(10s) fill(null)")
    unnamed_result = client.query("SELECT mean(value) FROM voc_ppm WHERE (sensor = \'Unnamed_gas_sensor\') AND time > " + start_time + " and time < " + end_time + " GROUP BY time(10s) fill(null)")
    seeed_result = client.query("SELECT mean(value) FROM voc_ppm WHERE (sensor = \'Seeed_Grove_HCHO_sensor\') AND time > " + start_time + " and time < " + end_time + " GROUP BY time(10s) fill(null)")

    #For each (label, result) pair, get the score list and return a dictionary 'score_dict' with all data for each sensor
    score_dict = {}
    for result in [("Sensirion_SEN54",sensirion_result), ("EC_Sense_PS1_VOC",ec_result), ("Unnamed_gas_sensor", unnamed_result), ("Seeed_Grove_HCHO_sensor",seeed_result)]:
        score_list = []
        for element in result[1].items():
            score_and_time = list(element[1])
            for item in score_and_time:
                #Do value adjustments for data
                if (item['mean'] != None) and result[0] == 'EC_Sense_PS1_VOC':
                    if item['mean'] < 5000:
                        score_list.append(item['mean'])
                    else:
                        score_list.append(np.NaN)
                elif (item['mean'] != None) and result[0] in ['Unnamed_gas_sensor','Seeed_Grove_HCHO_sensor']:
                    if item['mean']*1000 < 5000:
                        score_list.append(item['mean'] * 1000)
                    else:
                        score_list.append(np.NaN)  
                else:
                    score_list.append(item['mean'])
        score_dict[result[0]] = score_list
    return score_dict

def format_time_string(time_string):
    '''
    TODO
    '''
    split_spaces = time_string.split(" ")
    mm_dd_yy = split_spaces[0].split("/")
    return_string = "\'" + mm_dd_yy[2] + "-" + mm_dd_yy[0] + "-" + mm_dd_yy[1] + "T" + split_spaces[1] + ".00000000Z\'"
    return return_string

#--------------------------------------------
# Executable Script
#--------------------------------------------

#Defines the data that you are reading, this should have a chemical and dosage pair
df = pd.read_csv('./Data/box_test_data.csv', sep=',', header=0)

for plant in df["Plant"].unique():
    plant_df = df[df['Plant'] == plant]
    for index, row in plant_df.iterrows():
        #Use the Start Time and End Time to Query influx DB
        #Pull Awair Data and Store into pandas dataframe
        entry_to_crush1 = pull_awair_voc_data(format_time_string(row["Entry Time"]), format_time_string(row["Crush Time 1"]), '70886b126a0e')
        if row["Crush Time 1"] == 'None' and row["Crush Time 2"]=='None' and row["Crush Time 3"] == 'None':
            crush1_to_crush2 = None
            crush2_to_crush3 = None
            final_crush_to_exit = None
        elif row["Crush Time 2"]=='None' and row["Crush Time 3"] == 'None':
            crush1_to_crush2 = None
            crush2_to_crush3 = None
            final_crush_to_exit = pull_awair_voc_data(format_time_string(row["Crush Time 1"]), format_time_string(row["End Time"]), '70886b126a0e')
        elif row["Crush Time 3"] == 'None':
            crush1_to_crush2 = pull_awair_voc_data(format_time_string(row["Crush Time 1"]), format_time_string(row["Crush Time 2"]), '70886b126a0e')
            crush2_to_crush3 = None
            final_crush_to_exit = pull_awair_voc_data(format_time_string(row["Crush Time 2"]), format_time_string(row["End Time"]), '70886b126a0e')
        else:
            crush1_to_crush2 = pull_awair_voc_data(format_time_string(row["Crush Time 1"]), format_time_string(row["Crush Time 2"]), '70886b126a0e')
            crush2_to_crush3 = pull_awair_voc_data(format_time_string(row["Crush Time 2"]), format_time_string(row["Crush Time 3"]), '70886b126a0e')
            final_crush_to_exit = pull_awair_voc_data(format_time_string(row["Crush Time 3"]), format_time_string(row["End Time"]), '70886b126a0e')

        time_counter = 0
        color_counter = 0
        color_list = ['r','y','g','b']    
        for time_gap in [entry_to_crush1, crush1_to_crush2, crush2_to_crush3, final_crush_to_exit]:
            if time_gap == None:
                continue
            time_list = []
            for item in time_gap:
                time_list.append(time_counter)
                time_counter+=10
            plt.plot(time_list, time_gap, color_list[color_counter]+'.')
            color_counter+=1

plt.show()
