from lmfit import Model
import numpy as np
import matplotlib.pyplot as plt

def exponential_function(x, a, b, c):
    return a * np.exp(-b * x) + c


lmodel = Model(exponential_function)
params = lmodel.make_params(a=-60, b=30, c=10.25)

x_time= np.linspace(0, 10, 201)
y_voc = exponential_function(x_time, -2.33, 0.21, 1.51) + np.random.normal(0, 0.2, x_time.size)

result = lmodel.fit(y_voc, x=x_time, a=-5, b=5, c=1)
print(result.fit_report())
print(result.best_fit)

plt.plot(x_time, y_voc, 'o')
plt.plot(x_time, result.best_fit, '-', label='best fit')
plt.show()

