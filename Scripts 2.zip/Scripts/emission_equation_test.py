import math

#Define initial_variables
init_ppb_value = 123.0
init_temp_C = 19.1
init_molecular_weight = 136.23 

#Define sample variables:
ppb_value = 124.0                   #In ppb
temp_C = 20.3                #In degrees C
molecular_weight = 136.23           #In gram/mol

def ppb_conversion(ppb_value, temperature_C, molecular_weight):
    '''
    Converts ppb to micrograms/meter^3
    '''
    return (ppb_value * 12.187 * molecular_weight)/(273.15 + temperature_C)

Q = 290.5307                                                                #In meters^3/h           Ventilation air flow rate 171cfm -> 290.5307 meters^3/h
C = ppb_conversion(ppb_value, temp_C, molecular_weight)                     #In micrograms/meters^3  Concentration
C_in = ppb_conversion(init_ppb_value, init_temp_C, init_molecular_weight)   #In micrograms/meters^3  Initial Concentration
V = 29.65                                                                   #In meters^3             Volume
t = 0.25                                                                    #In hours                Time

def find_emission_rate(Q, C, C_in, V, t):
    numerator = C - (C_in * math.exp((-Q*t)/V))
    print((C_in * math.exp((-Q*t)/V)))
    denominator = 1 - math.exp((-Q*t)/V)
    print(math.exp((-Q*t)/V))
    return Q*(numerator/denominator)

#Results
print('Final Concentration:',C, 'micrograms/m^3')
print('Initial Concentration', C_in, 'micrograms/m^3')
print('Emission Rate after 15 minutes:', find_emission_rate(Q, C, C_in, V, t)/3600, "micrograms/second")