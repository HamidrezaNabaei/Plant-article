#!/usr/bin/env python3

import influxdb
from statistics import stdev, mean, median
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import lmfit

HOST = 'influx.linklab.virginia.edu'
PORT = 443
USERNAME = 'ryan'
PASSWORD = 'gae7shaerai9Xiem9eilae5shiGhuich4Gu'
DATABASE = 'gateway-generic'

client = influxdb.InfluxDBClient(HOST, PORT, USERNAME, PASSWORD, DATABASE, ssl=True, verify_ssl=True)

device_locations = ['Sensor A', 'Sensor B', 'Sensor Wall', 'Sensor Vertical']
device_ids = ['70886b123059', '70886b1235d4', '70886b1277ca', '70886b1230f2']

#--------------------------------------------
# Functions
#--------------------------------------------

def exponential_function(x, a, b, c):
    return a * np.exp(-b * x) + c

def f1(x, a0, a1, a2, a3):
    #https://stackoverflow.com/questions/34471006/how-to-determine-function-or-curve-fit-unknown-function-with-python
    return a0 + a1/x + a2/x**2 + a3/x**3

def f2(x, a0, a1, a2, a3):
    #https://stackoverflow.com/questions/34471006/how-to-determine-function-or-curve-fit-unknown-function-with-python
    return a0 + a1*x + a2*x**2 + a3*x**3

def logistic_function(x, x_0, L, k):
    #https://www.architecture-performance.fr/ap_blog/fitting-a-logistic-curve-to-time-series-in-python/
    return L/(1+np.exp(-k*(x-x_0)))    

def pull_awair_voc_data(start_time, end_time, device_id):
    '''
    This program checks to see if there are any VOC spikes by an inputted sensor

    TODO
    '''
    #Gets the value for the sensor that works
    result = client.query("SELECT MEAN(value) FROM voc_ppb WHERE (device_id = \'" + device_id + "\') and time > " + start_time + " and time < " + end_time + " GROUP BY location_specific, time(10s) fill(null)")
    score_list = []
    #For each element in the VOC data, grab the score and time. Within the score and time, grab just the score (aka the mean)
    for element in result.items():
                score_and_time = list(element[1])
                for item in score_and_time:
                    score_list.append(item['mean'])
    return score_list

def pull_new_voc_data(start_time, end_time):
    '''
    TODO
    '''
    #Pull all data for each individual sensor for a selected timeframe
    sensirion_result = client.query("SELECT mean(value) FROM voc_index WHERE (sensors = \'Sensirion_SEN54\') AND time > " + start_time + " and time < " + end_time + " GROUP BY time(10s) fill(null)")
    ec_result = client.query("SELECT mean(value) FROM voc_ppb WHERE (sensor = \'EC_Sense_PS1_VOC\') AND time > " + start_time + " and time < " + end_time + " GROUP BY time(10s) fill(null)")
    unnamed_result = client.query("SELECT mean(value) FROM voc_ppm WHERE (sensor = \'Unnamed_gas_sensor\') AND time > " + start_time + " and time < " + end_time + " GROUP BY time(10s) fill(null)")
    seeed_result = client.query("SELECT mean(value) FROM voc_ppm WHERE (sensor = \'Seeed_Grove_HCHO_sensor\') AND time > " + start_time + " and time < " + end_time + " GROUP BY time(10s) fill(null)")

    #For each (label, result) pair, get the score list and return a dictionary 'score_dict' with all data for each sensor
    score_dict = {}
    for result in [("Sensirion_SEN54",sensirion_result), ("EC_Sense_PS1_VOC",ec_result), ("Unnamed_gas_sensor", unnamed_result), ("Seeed_Grove_HCHO_sensor",seeed_result)]:
        score_list = []
        for element in result[1].items():
            score_and_time = list(element[1])
            for item in score_and_time:
                #Do value adjustments for data
                if (item['mean'] != None) and result[0] == 'EC_Sense_PS1_VOC':
                    if item['mean'] < 5000:
                        score_list.append(item['mean'])
                    else:
                        score_list.append(np.NaN)
                elif (item['mean'] != None) and result[0] in ['Unnamed_gas_sensor','Seeed_Grove_HCHO_sensor']:
                    if item['mean']*1000 < 5000:
                        score_list.append(item['mean'] * 1000)
                    else:
                        score_list.append(np.NaN)  
                else:
                    score_list.append(item['mean'])
        score_dict[result[0]] = score_list
    return score_dict

def format_time_string(time_string):
    '''
    TODO
    '''
    split_spaces = time_string.split(" ")
    mm_dd_yy = split_spaces[0].split("/")
    return_string = "\'" + mm_dd_yy[2] + "-" + mm_dd_yy[0] + "-" + mm_dd_yy[1] + "T" + split_spaces[1] + ".00000000Z\'"
    return return_string

#--------------------------------------------
# Executable Script
#--------------------------------------------

df = pd.read_csv('./Data/full_data.csv', sep=',', header=0)

for chemical in df["Chemical"].unique():
    chemical_df = df[df['Chemical'] == chemical]
    for dosage in chemical_df['Dosage'].unique():
        chem_dos_df = chemical_df[chemical_df['Dosage'] == dosage]
        plt.figure(str(chemical) + " " + str(dosage))
        #Pull out the values for each row
        for index, row in chem_dos_df.iterrows():
            #Use the Start Time and End Time to Query influx DB
            #Pull Awair Data and Store into pandas dataframe
            awair_voc_data_1 = pull_awair_voc_data(format_time_string(row["Start Time UTC"]), format_time_string(row["End Time UTC"]), '70886b1277ca')
            awair_voc_data_2 = pull_awair_voc_data(format_time_string(row["Start Time UTC"]), format_time_string(row["End Time UTC"]), '70886b123059')
            awair_voc_data_3 = pull_awair_voc_data(format_time_string(row["Start Time UTC"]), format_time_string(row["End Time UTC"]), '70886b1235d4')
            awair_voc_data_4 = pull_awair_voc_data(format_time_string(row["Start Time UTC"]), format_time_string(row["End Time UTC"]), '70886b1230f2')
            awair_data = {"AWAIR_SENSOR_1": awair_voc_data_1, "AWAIR_SENSOR_2" : awair_voc_data_2, "AWAIR_SENSOR_3" : awair_voc_data_3, "AWAIR_SENSOR_4" : awair_voc_data_4}
            room_voc_df = pd.DataFrame(awair_data)
            #Find Median and Mean and store in pandas dataframe
            awair_mean = room_voc_df.mean(axis=1)
            awair_median = room_voc_df.median(axis=1)
            room_voc_df["AWAIR_MEAN"] = awair_mean
            room_voc_df["AWAIR_MEDIAN"] = awair_median
            #Pull Other sensor data and store into pandas dataframe
            new_sensors_voc_data = pull_new_voc_data(format_time_string(row["Start Time UTC Plus"]), format_time_string(row["End Time UTC Plus"]))
            try:
                room_voc_df["Sensirion_SEN54"] = new_sensors_voc_data["Sensirion_SEN54"]
            except:
                room_voc_df["Sensirion_SEN54"] = np.nan
            try:
                room_voc_df["EC_Sense_PS1_VOC"] = new_sensors_voc_data["EC_Sense_PS1_VOC"]
            except:
                room_voc_df["EC_Sense_PS1_VOC"] = np.nan
            try:
                room_voc_df["Unnamed_gas_sensor"] = new_sensors_voc_data["Unnamed_gas_sensor"]
            except:
                room_voc_df["Unnamed_gas_sensor"] = np.nan
            try:
                room_voc_df["Seeed_Grove_HCHO_sensor"] = new_sensors_voc_data["Seeed_Grove_HCHO_sensor"]
            except:
                room_voc_df["Seeed_Grove_HCHO_sensor"] = np.nan
            #Pull NumpyArray
            y_points = room_voc_df['AWAIR_SENSOR_1'].to_numpy()
            x_points_1second = list(range(len(y_points)))
            x_points_10seconds = [i * 10 for i in x_points_1second]
            graph_df = pd.DataFrame(data=y_points, columns=['y_data'])
            graph_df['x_data'] = x_points_10seconds
            graph_df=graph_df.dropna().reset_index(drop=True)
            #Graph Logrithmic Curve
            # lmodel = lmfit.Model(logistic_function)
            # params = lmodel.make_params(x_0=1,L=1,k=1)
            # result = lmodel.fit(graph_df['y_data'].to_numpy(),x=graph_df['x_data'].to_numpy(),nan_policy='omit', params=params, x_0=1,L=1,k=1)
            # lmodel = lmfit.Model(f2)
            # params = lmodel.make_params(a0=1, a1=1, a2=1, a3=1)
            # result = lmodel.fit(graph_df['y_data'],x=graph_df['x_data'],params=params, nan_policy='omit', a0=1, a1=1, a2=1, a3=1)
            # print(chemical+dosage)
            # print("-----------------")
            # print(result.fit_report())
            plt.plot(graph_df['x_data'], graph_df['y_data'].tolist(), '.', label = row['Start Time']) #To get the lines to work, change the query to query every 10 seconds
            # plt.plot(graph_df['x_data'], result.best_fit, '-', label='best fit')
        plt.legend()
        plt.title(str(chemical) + " " + str(dosage))
        plt.xlabel("Time (sec)")
        plt.ylabel("TVOCs (ppb)")

plt.show()