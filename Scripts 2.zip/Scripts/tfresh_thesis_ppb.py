#!/usr/bin/env python3

import influxdb
from statistics import stdev, mean, median
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import lmfit 
from scipy.stats import randint
from cf_matrix import *

from tsfresh import extract_features
from tsfresh.feature_extraction import ComprehensiveFCParameters
from tsfresh.feature_extraction.settings import TimeBasedFCParameters
from tsfresh import select_features
from tsfresh.utilities.dataframe_functions import impute
from tsfresh import extract_relevant_features

from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.feature_selection import SelectFromModel
from sklearn import svm
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler

from xgboost import XGBClassifier

HOST = 'influx.linklab.virginia.edu'
PORT = 443
USERNAME = 'ryan'
PASSWORD = 'gae7shaerai9Xiem9eilae5shiGhuich4Gu'
DATABASE = 'gateway-generic'

client = influxdb.InfluxDBClient(HOST, PORT, USERNAME, PASSWORD, DATABASE, ssl=True, verify_ssl=True)

device_locations = ['Sensor A', 'Sensor B', 'Sensor Wall', 'Sensor Vertical']
device_ids = ['70886b123059', '70886b1235d4', '70886b1277ca', '70886b1230f2']

#--------------------------------------------
# Functions
#--------------------------------------------

def exponential_function(x, a, b, c):
    return a * np.exp(-b * x) + c

def f1(x, a0, a1, a2, a3):
    #https://stackoverflow.com/questions/34471006/how-to-determine-function-or-curve-fit-unknown-function-with-python
    return a0 + a1/x + a2/x**2 + a3/x**3

def f2(x, a0, a1, a2, a3):
    #https://stackoverflow.com/questions/34471006/how-to-determine-function-or-curve-fit-unknown-function-with-python
    return a0 + a1*x + a2*x**2 + a3*x**3

def logistic_function(x, x_0, L, k):
    #https://www.architecture-performance.fr/ap_blog/fitting-a-logistic-curve-to-time-series-in-python/
    return L/(1+np.exp(-k*(x-x_0)))    

def pull_awair_voc_data(start_time, end_time, device_id):
    '''
    This program checks to see if there are any VOC spikes by an inputted sensor

    TODO
    '''
    #Gets the value for the sensor that works
    result = client.query("SELECT MEAN(value) FROM voc_ppb WHERE (device_id = \'" + device_id + "\') and time > " + start_time + " and time < " + end_time + " GROUP BY location_specific, time(10s) fill(null)")
    score_list = []
    #For each element in the VOC data, grab the score and time. Within the score and time, grab just the score (aka the mean)
    for element in result.items():
                score_and_time = list(element[1])
                for item in score_and_time:
                    score_list.append(item['mean'])
    return score_list

def pull_new_voc_data(start_time, end_time):
    '''
    TODO
    '''
    #Pull all data for each individual sensor for a selected timeframe
    sensirion_result = client.query("SELECT mean(value) FROM voc_index WHERE (sensors = \'Sensirion_SEN54\') AND time > " + start_time + " and time < " + end_time + " GROUP BY time(10s) fill(null)")
    ec_result = client.query("SELECT mean(value) FROM voc_ppb WHERE (sensor = \'EC_Sense_PS1_VOC\') AND time > " + start_time + " and time < " + end_time + " GROUP BY time(10s) fill(null)")
    unnamed_result = client.query("SELECT mean(value) FROM voc_ppm WHERE (sensor = \'Unnamed_gas_sensor\') AND time > " + start_time + " and time < " + end_time + " GROUP BY time(10s) fill(null)")
    seeed_result = client.query("SELECT mean(value) FROM voc_ppm WHERE (sensor = \'Seeed_Grove_HCHO_sensor\') AND time > " + start_time + " and time < " + end_time + " GROUP BY time(10s) fill(null)")

    #For each (label, result) pair, get the score list and return a dictionary 'score_dict' with all data for each sensor
    score_dict = {}
    for result in [("Sensirion_SEN54",sensirion_result), ("EC_Sense_PS1_VOC",ec_result), ("Unnamed_gas_sensor", unnamed_result), ("Seeed_Grove_HCHO_sensor",seeed_result)]:
        score_list = []
        for element in result[1].items():
            score_and_time = list(element[1])
            for item in score_and_time:
                #Do value adjustments for data
                if (item['mean'] != None) and result[0] == 'EC_Sense_PS1_VOC':
                    if item['mean'] < 5000:
                        score_list.append(item['mean'])
                    else:
                        score_list.append(np.NaN)
                elif (item['mean'] != None) and result[0] in ['Unnamed_gas_sensor','Seeed_Grove_HCHO_sensor']:
                    if item['mean']*1000 < 5000:
                        score_list.append(item['mean'] * 1000)
                    else:
                        score_list.append(np.NaN)  
                else:
                    score_list.append(item['mean'])
        score_dict[result[0]] = score_list
    return score_dict

def format_time_string(time_string):
    '''
    TODO
    '''
    split_spaces = time_string.split(" ")
    mm_dd_yy = split_spaces[0].split("/")
    return_string = "\'" + mm_dd_yy[2] + "-" + mm_dd_yy[0] + "-" + mm_dd_yy[1] + "T" + split_spaces[1] + ".00000000Z\'"
    return return_string

#--------------------------------------------
# Executable Script
#--------------------------------------------

if __name__ == '__main__':
    complete_df = pd.DataFrame(columns=['id', 'time', 'value'])
    complete_y = pd.Series()

    df = pd.read_csv('./Data/citral-cis-dlim.csv', sep=',', header=0)

    chem_dos_id = 0
    for chemical in df["Chemical"].unique():
        chemical_df = df[df['Chemical'] == chemical]
        for dosage in chemical_df['Dosage'].unique():
            chem_dos_df = chemical_df[chemical_df['Dosage'] == dosage]
            #Pull out the values for each row
            for index, row in chem_dos_df.iterrows():
                #Use the Start Time and End Time to Query influx DB
                #Pull Awair Data and Store into pandas dataframe
                awair_voc_data_1 = pull_awair_voc_data(format_time_string(row["Start Time UTC"]), format_time_string(row["End Time UTC"]), '70886b1277ca')
                awair_voc_data_2 = pull_awair_voc_data(format_time_string(row["Start Time UTC"]), format_time_string(row["End Time UTC"]), '70886b123059')
                awair_voc_data_3 = pull_awair_voc_data(format_time_string(row["Start Time UTC"]), format_time_string(row["End Time UTC"]), '70886b1235d4')
                awair_voc_data_4 = pull_awair_voc_data(format_time_string(row["Start Time UTC"]), format_time_string(row["End Time UTC"]), '70886b1230f2')
                awair_data = {"AWAIR_SENSOR_1": awair_voc_data_1, "AWAIR_SENSOR_2" : awair_voc_data_2, "AWAIR_SENSOR_3" : awair_voc_data_3, "AWAIR_SENSOR_4" : awair_voc_data_4}
                room_voc_df = pd.DataFrame(awair_data)
                #Find Median and Mean and store in pandas dataframe
                awair_mean = room_voc_df.mean(axis=1)
                awair_median = room_voc_df.median(axis=1)
                room_voc_df["AWAIR_MEAN"] = awair_mean
                room_voc_df["AWAIR_MEDIAN"] = awair_median
                time_1_second = list(range(len(awair_mean)))
                time_10_second = [i * 10 for i in time_1_second]
                room_voc_df['time'] = time_10_second
                for awair_sensor in ["AWAIR_SENSOR_1", "AWAIR_SENSOR_2", "AWAIR_SENSOR_3", "AWAIR_SENSOR_4"]:
                    room_voc_df['id'] = chem_dos_id
                    room_voc_df['value'] = room_voc_df[awair_sensor]
                    room_voc_df.dropna(inplace=True)
                    y = pd.Series([chemical+dosage], index=[chem_dos_id])
                    #Add the values in the correct format to the complete df dataset
                    complete_df = pd.concat([complete_df, room_voc_df], join="inner")
                    #Add the labels to the y dataset
                    complete_y = pd.concat([complete_y, y])
                    #print(complete_df)
                    #print(complete_y)
                    chem_dos_id+=1

    extraction_settings = ComprehensiveFCParameters()
    time_settings = TimeBasedFCParameters()
    custom_settings = {
        "autocorrelation": [{"lag":1},{"lag":3},{"lag":5},{"lag":8}],
        "approximate_entropy": [{"m":2, "r":0.7}],
        "sample_entropy": None,
        "lempel_ziv_complexity":[{"bins":2},{"bins":3}],
        "permutation_entropy": [{"tau":1, "dimension":3},{"tau":1, "dimension":4}],
        "longest_strike_above_mean" : None,
        }
    X = extract_features(complete_df, column_id="id", column_sort="time", default_fc_parameters=extraction_settings, column_kind=None, column_value=None)
    impute(X)
    #X_filtered = select_features(X, complete_y)

    X_full_train, X_full_test, y_train, y_test = train_test_split(X, complete_y, test_size=.2, random_state=21)
    X_filtered_train, X_filtered_test = X_full_train, X_full_test #-- used for when filtered does not extract anything
    #X_filtered_train, X_filtered_test = X_full_train[X_filtered.columns], X_full_test[X_filtered.columns]

    scaler = StandardScaler()
    X_filtered_train_scaled = scaler.fit_transform(X_filtered_train)
    X_filtered_test_scaled = scaler.transform(X_filtered_test)

    # Confusion Matrix Fields
    categories = ["Citral", "Cis-Beta Ocimene", "D-Limonene"]

    # Random Forest w/ Feature Selection

    sel = SelectFromModel(RandomForestClassifier(n_estimators = 100), max_features=15)
    sel.fit(X_filtered_train, y_train)
    selected_feat= X_filtered_train.columns[(sel.get_support())]
    print(list(selected_feat))
    X_filtered_train_15 = X_filtered_train[list(selected_feat)]
    X_filtered_test_15 = X_filtered_test[list(selected_feat)]

    # random_forest_list = list(selected_feat)

    print("\nRandom Forest\n")
    rf_filtered = RandomForestClassifier(n_estimators = 200)
    rf_filtered.fit(X_filtered_train_15, y_train)
    print(classification_report(y_test, rf_filtered.predict(X_filtered_test_15)))
    conf_mat = confusion_matrix(y_test, rf_filtered.predict(X_filtered_test_15))
    make_confusion_matrix(conf_mat, figsize=(8,8), cbar=False, title="Random Forest", categories=categories, sum_stats=False)
    #print(conf_mat)

    # SVM w/ Feature Selection

    print("\nSVM\n")
    clf = svm.SVC(kernel='linear')
    clf.fit(X_filtered_train_scaled, y_train)
    print(classification_report(y_test, clf.predict(X_filtered_test_scaled)))
    conf_mat = confusion_matrix(y_test, clf.predict(X_filtered_test_scaled))
    make_confusion_matrix(conf_mat, figsize=(8,8), cbar=False, title="SVM", categories=categories, sum_stats=False)
    #print(conf_mat)

    # XGBoost w/ Feature Selection

    y_test_xgb = y_test.replace( ['Citral200 mic','Cis-Beta Ocimene 70%200 mic', 'D-Limonene200 mic'], [0,1,2])
    y_train_xgb = y_train.replace( ['Citral200 mic', 'Cis-Beta Ocimene 70%200 mic', 'D-Limonene200 mic'], [0,1,2])
    sel = SelectFromModel(XGBClassifier(), max_features=15)
    sel.fit(X_filtered_train, y_train_xgb)
    selected_feat= X_filtered_train.columns[(sel.get_support())]
    print(list(selected_feat))
    X_filtered_train_15 = X_filtered_train[list(selected_feat)]
    X_filtered_test_15 = X_filtered_test[list(selected_feat)]

    # xgboost_list = list(selected_feat)

    print("\nXGBoost\n")
    xgb_classifier = XGBClassifier()
    xgb_classifier.fit(X_filtered_train_15, y_train_xgb)
    print(classification_report(y_test_xgb, xgb_classifier.predict(X_filtered_test_15)))
    conf_mat = confusion_matrix(y_test_xgb, xgb_classifier.predict(X_filtered_test_15))
    make_confusion_matrix(conf_mat, figsize=(8,8), cbar=False, title="XGBoost", categories=categories, sum_stats=False)
    #print(conf_mat)


    # print(set(xgboost_list) & set(random_forest_list))
    # KNN w/ Feature Selection

    # print("\nKNN\n")
    # knn_classifier = KNeighborsClassifier(n_neighbors = 5, metric = 'minkowski', p = 2)
    # knn_classifier.fit(X_filtered_train_scaled, y_train)
    # print(classification_report(y_test, knn_classifier.predict(X_filtered_test_scaled)))
    # conf_mat = confusion_matrix(y_test, knn_classifier.predict(X_filtered_test_scaled))
    # print(conf_mat)
    
    plt.show()