import math
import influxdb
from statistics import stdev, mean, median
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import lmfit

HOST = 'influx.linklab.virginia.edu'
PORT = 443
USERNAME = 'ryan'
PASSWORD = 'gae7shaerai9Xiem9eilae5shiGhuich4Gu'
DATABASE = 'gateway-generic'

client = influxdb.InfluxDBClient(HOST, PORT, USERNAME, PASSWORD, DATABASE, ssl=True, verify_ssl=True)

#Define initial_variables
init_ppb_value = 123.0
init_temp_C = 19.1
init_molecular_weight = 136.23 

#Define sample variables:
ppb_value = 124.0                   #In ppb
temp_C = 20.3                #In degrees C
molecular_weight = 136.23           #In gram/mol

def ppb_conversion(ppb_value, temperature_C, molecular_weight):
    '''
    Converts ppb to micrograms/meter^3
    '''
    return (ppb_value * 12.187 * molecular_weight)/(273.15 + temperature_C)

def format_time_string(time_string):
    '''
    TODO
    '''
    split_spaces = time_string.split(" ")
    mm_dd_yy = split_spaces[0].split("/")
    return_string = "\'" + mm_dd_yy[2] + "-" + mm_dd_yy[0] + "-" + mm_dd_yy[1] + "T" + split_spaces[1] + ".00000000Z\'"
    return return_string

def pull_awair_voc_data(start_time, end_time, device_id):
    '''
    This program checks to see if there are any VOC spikes by an inputted sensor

    TODO
    '''
    #Gets the value for the sensor that works
    molecular_weight = 28.97          #In gram/mol
    #Grab temperature
    temp_list = []
    temp_result = client.query('SELECT MEAN(value) FROM "Temperature_°C" WHERE (device_id = \'' + device_id + "\') and time > " + start_time + " and time < " + end_time + " GROUP BY location_specific, time(10s) fill(null)")
    for element in temp_result.items():
            score_and_time = list(element[1])
            for item in score_and_time:
                temp_list.append(item['mean'])
    result = client.query("SELECT MEAN(value) FROM voc_ppb WHERE (device_id = \'" + device_id + "\') and time > " + start_time + " and time < " + end_time + " GROUP BY location_specific, time(10s) fill(null)")
    score_list = []
    #For each element in the VOC data, grab the score and time. Within the score and time, grab just the score (aka the mean)
    for element in result.items():
            score_and_time = list(element[1])
            for item in score_and_time:
                score_list.append(item['mean'])
    for index in range(len(score_list)):
        if temp_list[index] == None:
            temp_list[index] = temp_list[index-1]
        if score_list[index] != None:
            score_list[index] = ppb_conversion(score_list[index], temp_list[index], molecular_weight)
    return score_list

def pull_ventilation_air_flow(start_time, end_time):
    '''
    TODO - Figure out how to pull values from here
    '''
    query = "SELECT mean(\"value\") FROM \"supply_airflow_cfm\" WHERE (\"receiver\" = \'facilities\') AND time > " + start_time + " and time < " + end_time + " GROUP BY \"location_specific\" fill(null);"
    temp_result = client.query(query)
    #temp_result = client.query("SELECT mean(value) FROM \"supply_airflow_cfm\" WHERE (\"receiver\" = 'facilities') AND time >= 1674563873131ms and time <= 1674570159318ms GROUP BY time(5s), \"location_specific\" fill(null);")
    for element in temp_result.items():
        location_data = list(element[0])
        if location_data[1]['location_specific'] == '275 Olsson':
            Q_value = list(element[1])[0]['mean'] * 1.699
    return Q_value


def find_emission_rate(Q, C, C_in, V, t):
    numerator = C - (C_in * math.exp((-Q*t)/V))
    denominator = 1 - math.exp((-Q*t)/V)
    return Q*(numerator/denominator)

def calculate_concentration(Q, F, C_in, V, t):
    return (C_in - (F/Q))*math.exp(-(Q*t)/V) + F/Q



#print('Emission Rate after 15 minutes:', find_emission_rate(Q, C, C_in, V, t)/3600, "micrograms/second")

df = pd.read_csv('./Data/finalized_testing.csv', sep=',', header=0)

for chemical in df["Chemical"].unique():
    chemical_df = df[df['Chemical'] == chemical]
    for dosage in chemical_df['Dosage'].unique():
        chem_dos_df = chemical_df[chemical_df['Dosage'] == dosage]
        plt.figure(str(chemical) + " " + str(dosage))
        #Pull out the values for each row
        emission_rate_list = []
        for index, row in chem_dos_df.iterrows():
            awair_voc_data_1 = pull_awair_voc_data(format_time_string(row["Start Time UTC"]), format_time_string(row["End Time UTC"]), '70886b1277ca')
            awair_voc_data_2 = pull_awair_voc_data(format_time_string(row["Start Time UTC"]), format_time_string(row["End Time UTC"]), '70886b123059')
            awair_voc_data_3 = pull_awair_voc_data(format_time_string(row["Start Time UTC"]), format_time_string(row["End Time UTC"]), '70886b1235d4')
            awair_voc_data_4 = pull_awair_voc_data(format_time_string(row["Start Time UTC"]), format_time_string(row["End Time UTC"]), '70886b1230f2')
            awair_data = {"AWAIR_SENSOR_1": awair_voc_data_1, "AWAIR_SENSOR_2" : awair_voc_data_2, "AWAIR_SENSOR_3" : awair_voc_data_3, "AWAIR_SENSOR_4" : awair_voc_data_4}
            room_voc_df = pd.DataFrame(awair_data)
            #Find Median and Mean and store in pandas dataframe
            awair_mean = room_voc_df.mean(axis=1)
            awair_median = room_voc_df.median(axis=1)
            room_voc_df["AWAIR_MEAN"] = awair_mean
            room_voc_df["AWAIR_MEDIAN"] = awair_median
            reading_id = 'AWAIR_SENSOR_4'
            average_ppb = room_voc_df[reading_id].to_list()
            time_1_second = list(range(len(average_ppb)))
            time_10_second_to_hour = [i * 10/3600 for i in time_1_second]
            room_voc_df['Time'] = time_10_second_to_hour
            print(room_voc_df)
            # #Q = 290.5307                                                                #In meters^3/h           Ventilation air flow rate 171cfm -> 290.5307 meters^3/h
            # Q = pull_ventilation_air_flow(format_time_string(row["Start Time UTC"]), format_time_string(row["End Time UTC"]))
            # V = 29.65                                                                   #In meters^3             Volume
            # emission_rates = []
            # #Grab the median of the first 5 values to be used as the initial concentration
            # initial_concentration = room_voc_df.head().median(axis = 0)[reading_id]
            # for i in range(len(average_ppb)):
            #     try:
            #         emission_rates.append(find_emission_rate(Q, average_ppb[i], initial_concentration, V, time_10_second_to_hour[i]))
            #     except:
            #         emission_rates.append(None)
            # room_voc_df["EMISSION_RATE_AT_TIME"] = emission_rates
            # print(room_voc_df)