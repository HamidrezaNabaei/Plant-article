from tsfresh.examples.robot_execution_failures import download_robot_execution_failures, load_robot_execution_failures
import matplotlib.pyplot as plt
from tsfresh import extract_features
from tsfresh import select_features
from tsfresh.utilities.dataframe_functions import impute
from tsfresh import extract_relevant_features

from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

if __name__ == '__main__':
    download_robot_execution_failures()
    timeseries, y = load_robot_execution_failures()

    print(type(y))

    X = extract_features(timeseries, column_id="id", column_sort="time")
    #print(extracted_features['id'])
    impute(X)
    X_filtered  = select_features(X, y)
    #print(features_filtered)
    X_full_train, X_full_test, y_train, y_test = train_test_split(X, y, test_size=.2)
    X_filtered_train, X_filtered_test = X_full_train[X_filtered.columns], X_full_test[X_filtered.columns]
 
    classifier_full = DecisionTreeClassifier()
    classifier_full.fit(X_full_train, y_train)
    print(classification_report(y_test, classifier_full.predict(X_full_test)))
    classifier_filtered = DecisionTreeClassifier()
    classifier_filtered.fit(X_filtered_train, y_train)
    print(classification_report(y_test, classifier_filtered.predict(X_filtered_test)))
