#!/usr/bin/env python3

import influxdb
from statistics import stdev, mean, median
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import lmfit
import matplotlib.patheffects as pe

HOST = 'influx.linklab.virginia.edu'
PORT = 443
USERNAME = 'ryan'
PASSWORD = 'gae7shaerai9Xiem9eilae5shiGhuich4Gu'
DATABASE = 'gateway-generic'

client = influxdb.InfluxDBClient(HOST, PORT, USERNAME, PASSWORD, DATABASE, ssl=True, verify_ssl=True)

device_locations = ['Sensor A', 'Sensor B', 'Sensor Wall', 'Sensor Vertical']
device_ids = ['70886b123059', '70886b1235d4', '70886b1277ca', '70886b1230f2']

#--------------------------------------------
# Functions
#--------------------------------------------

def exponential_function(x, a, b, c):
    return a * np.exp(-b * x) + c

def f1(x, a0, a1, a2, a3):
    #https://stackoverflow.com/questions/34471006/how-to-determine-function-or-curve-fit-unknown-function-with-python
    return a0 + a1/x + a2/x**2 + a3/x**3

def f2(x, a0, a1, a2, a3):
    #https://stackoverflow.com/questions/34471006/how-to-determine-function-or-curve-fit-unknown-function-with-python
    return a0 + a1*x + a2*x**2 + a3*x**3

def logistic_function(x, x_0, L, k):
    #https://www.architecture-performance.fr/ap_blog/fitting-a-logistic-curve-to-time-series-in-python/
    return L/(1+np.exp(-k*(x-x_0)))    

def pull_awair_voc_data(start_time, end_time, device_id):
    '''
    This program checks to see if there are any VOC spikes by an inputted sensor

    TODO
    '''
    #Gets the value for the sensor that works
    result = client.query("SELECT MEAN(value) FROM voc_ppb WHERE (device_id = \'" + device_id + "\') and time > " + start_time + " and time < " + end_time + " GROUP BY location_specific, time(10s) fill(null)")
    score_list = []
    #For each element in the VOC data, grab the score and time. Within the score and time, grab just the score (aka the mean)
    for element in result.items():
                score_and_time = list(element[1])
                for item in score_and_time:
                    score_list.append(item['mean'])
    return score_list

def pull_new_voc_data(start_time, end_time):
    '''
    TODO
    '''
    #Pull all data for each individual sensor for a selected timeframe
    sensirion_result = client.query("SELECT mean(value) FROM voc_index WHERE (sensors = \'Sensirion_SEN54\') AND time > " + start_time + " and time < " + end_time + " GROUP BY time(10s) fill(null)")
    ec_result = client.query("SELECT mean(value) FROM voc_ppb WHERE (sensor = \'EC_Sense_PS1_VOC\') AND time > " + start_time + " and time < " + end_time + " GROUP BY time(10s) fill(null)")
    unnamed_result = client.query("SELECT mean(value) FROM voc_ppm WHERE (sensor = \'Unnamed_gas_sensor\') AND time > " + start_time + " and time < " + end_time + " GROUP BY time(10s) fill(null)")
    seeed_result = client.query("SELECT mean(value) FROM voc_ppm WHERE (sensor = \'Seeed_Grove_HCHO_sensor\') AND time > " + start_time + " and time < " + end_time + " GROUP BY time(10s) fill(null)")

    #For each (label, result) pair, get the score list and return a dictionary 'score_dict' with all data for each sensor
    score_dict = {}
    for result in [("Sensirion_SEN54",sensirion_result), ("EC_Sense_PS1_VOC",ec_result), ("Unnamed_gas_sensor", unnamed_result), ("Seeed_Grove_HCHO_sensor",seeed_result)]:
        score_list = []
        for element in result[1].items():
            score_and_time = list(element[1])
            for item in score_and_time:
                #Do value adjustments for data
                if (item['mean'] != None) and result[0] == 'EC_Sense_PS1_VOC':
                    if item['mean'] < 5000:
                        score_list.append(item['mean'])
                    else:
                        score_list.append(np.NaN)
                elif (item['mean'] != None) and result[0] in ['Unnamed_gas_sensor','Seeed_Grove_HCHO_sensor']:
                    if item['mean']*1000 < 5000:
                        score_list.append(item['mean'] * 1000)
                    else:
                        score_list.append(np.NaN)  
                else:
                    score_list.append(item['mean'])
        score_dict[result[0]] = score_list
    return score_dict

def format_time_string(time_string):
    '''
    TODO
    '''
    split_spaces = time_string.split(" ")
    mm_dd_yy = split_spaces[0].split("/")
    return_string = "\'" + mm_dd_yy[2] + "-" + mm_dd_yy[0] + "-" + mm_dd_yy[1] + "T" + split_spaces[1] + ".00000000Z\'"
    return return_string

#--------------------------------------------
# Executable Script
#--------------------------------------------

df = pd.read_csv('./Data/final_dataset.csv', sep=',', header=0)

citral_data = {1:{}, 2:{}, 3:{}, 4:{}}
#color_counter = 0
#color_list = ['r','y','g','b','c','k','m','w','r','y']

for chemical in df["Chemical"].unique():
    chemical_df = df[df['Chemical'] == chemical]
    for dosage in chemical_df['Dosage'].unique():
        chem_dos_df = chemical_df[chemical_df['Dosage'] == dosage]
        #plt.figure(str(chemical) + " " + str(dosage))
        #Pull out the values for each row
        awair_sensor_1_readings = {}
        awair_sensor_2_readings = {}
        awair_sensor_3_readings = {}
        awair_sensor_4_readings = {}
        counter = 0
        for index, row in chem_dos_df.iterrows():
            #Use the Start Time and End Time to Query influx DB
            #Pull Awair Data and Store into pandas dataframe
            awair_voc_data_1 = pull_awair_voc_data(format_time_string(row["Start Time UTC"]), format_time_string(row["End Time UTC"]), '70886b1277ca')
            awair_voc_data_2 = pull_awair_voc_data(format_time_string(row["Start Time UTC"]), format_time_string(row["End Time UTC"]), '70886b123059')
            awair_voc_data_3 = pull_awair_voc_data(format_time_string(row["Start Time UTC"]), format_time_string(row["End Time UTC"]), '70886b1235d4')
            awair_voc_data_4 = pull_awair_voc_data(format_time_string(row["Start Time UTC"]), format_time_string(row["End Time UTC"]), '70886b1230f2')
            if len(awair_voc_data_1) > 90:
                awair_voc_data_1.pop(90)
            if len(awair_voc_data_2) > 90:
                awair_voc_data_2.pop(90)
            if len(awair_voc_data_3) > 90:
                awair_voc_data_3.pop(90)
            if len(awair_voc_data_4) > 90:
                awair_voc_data_4.pop(90)
            awair_sensor_1_readings["Reading " + str(counter)] = awair_voc_data_1
            awair_sensor_2_readings["Reading " + str(counter)] = awair_voc_data_2
            awair_sensor_3_readings["Reading " + str(counter)] = awair_voc_data_3
            awair_sensor_4_readings["Reading " + str(counter)] = awair_voc_data_4
            counter +=1
        #print(awair_sensor_1_readings)
        # if chemical == "Cis-Beta Ocimene 70%":
        #     if dosage == "200 mic":
        #         citral_data[1] = awair_sensor_1_readings
        #         citral_data[2] = awair_sensor_2_readings
        #         citral_data[3] = awair_sensor_3_readings
        #         citral_data[4] = awair_sensor_4_readings
        sensor1_df = pd.DataFrame(awair_sensor_1_readings)
        awair_sensor_1_mean = sensor1_df.mean(axis=1)
        sensor2_df = pd.DataFrame(awair_sensor_2_readings)
        awair_sensor_2_mean = sensor2_df.mean(axis=1)
        sensor3_df = pd.DataFrame(awair_sensor_3_readings)
        awair_sensor_3_mean = sensor3_df.mean(axis=1)
        sensor4_df = pd.DataFrame(awair_sensor_4_readings)
        awair_sensor_4_mean = sensor4_df.mean(axis=1)
        # time_list = []
        # for i in range(90):
        #     time_list.append(i * 10)
        fig, axs = plt.subplots(2, 2)
        time_list = np.arange(0, 900, 10, dtype=int)
        print(awair_sensor_1_mean)
        for key in awair_sensor_1_readings.keys():
            series1 = np.array(awair_sensor_1_readings[key]).astype(np.double)
            s1mask = np.isfinite(series1)
            axs[0,0].plot(time_list[s1mask], series1[s1mask],'-',linewidth=0.5)
        for key in awair_sensor_2_readings.keys():
            series1 = np.array(awair_sensor_2_readings[key]).astype(np.double)
            s1mask = np.isfinite(series1)
            axs[0,1].plot(time_list[s1mask], series1[s1mask],'-',linewidth=0.5)
        for key in awair_sensor_3_readings.keys():
            series1 = np.array(awair_sensor_3_readings[key]).astype(np.double)
            s1mask = np.isfinite(series1)
            axs[1,0].plot(time_list[s1mask], series1[s1mask],'-',linewidth=0.5)
        for key in awair_sensor_4_readings.keys():
            series1 = np.array(awair_sensor_4_readings[key]).astype(np.double)
            s1mask = np.isfinite(series1)
            axs[1,1].plot(time_list[s1mask], series1[s1mask],'-',linewidth=0.5)
        # color_counter+=1
        axs[0,0].plot(time_list, awair_sensor_1_mean, '-', label = "Average Trace", color="white", linewidth=1.0, path_effects=[pe.Stroke(linewidth=5, foreground='k'), pe.Normal()]) #To get the lines to work, change the query to query every 10 seconds
        axs[0, 0].set_title('Sensor 1')
        axs[0,0].legend()
        axs[0,1].plot(time_list, awair_sensor_2_mean, '-', label = "Average Trace", color="white", linewidth=1.0, path_effects=[pe.Stroke(linewidth=5, foreground='k'), pe.Normal()]) #To get the lines to work, change the query to query every 10 seconds
        axs[0, 1].set_title('Sensor 2')
        axs[0,1].legend()
        axs[1,0].plot(time_list, awair_sensor_3_mean, '-', label = "Average Trace", color="white", linewidth=1.0, path_effects=[pe.Stroke(linewidth=5, foreground='k'), pe.Normal()]) #To get the lines to work, change the query to query every 10 seconds
        axs[1, 0].set_title('Sensor 3')
        axs[1,0].legend()
        axs[1,1].plot(time_list, awair_sensor_4_mean, '-', label = "Average Trace", color="white", linewidth=1.0, path_effects=[pe.Stroke(linewidth=5, foreground='k'), pe.Normal()]) #To get the lines to work, change the query to query every 10 seconds
        axs[1, 1].set_title('Sensor 4')
        axs[1,1].legend()
        if str(dosage) == "Nothing":
            fig.suptitle("All Traces and Average of All Traces for " + str(chemical) + " ")
        else:
            fig.suptitle("All Traces Average of All Traces for " + str(chemical) + " " + str(dosage))
        # plt.title("All Traces for Terpenes At Sensor 1")
        # plt.xlabel("Time (sec)")
        # plt.ylabel("TVOCs (ppb)")

# print(citral_data)
# plt.figure("Citral_Data")
# plt.title("All Citral Cases At AWAIR Sensor 3")
# plt.xlabel("Time (sec)")
# plt.ylabel("TVOCs (ppb)")
# for key in citral_data[3].keys():
#     plt.plot(time_list, citral_data[3][key], '--o', label = key)


plt.show()